const express = require('express');
const bodyParser = require('body-parser');
const { MessagingResponse } = require('twilio').twiml;

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

app.post('/whatsapp', (req, res) => {
  const msg = req.body.Body?.toLowerCase() || '';
  const twiml = new MessagingResponse();
  const response = twiml.message();

  if (msg.includes('1')) {
    response.body('Para agendar uma consulta, por favor envie seu nome completo, especialidade desejada e um telefone para contato.');
  } else if (msg.includes('2')) {
    response.body('Nossos atendentes disponíveis:
- Ana (Seg a Sex)
- Marcos (Seg a Sáb)
Entre em contato conosco para ser direcionado.');
  } else if (msg.includes('3')) {
    response.body('Estamos localizados na Rua das Flores, 123 - Centro, São Paulo/SP.');
  } else if (msg.includes('4')) {
    response.body('Horário de funcionamento:
Seg a Sex: 08h às 18h
Sábados: 08h às 12h
Domingos e feriados: fechado.');
  } else if (msg.includes('5')) {
    response.body('Especialidades disponíveis:
- Cardiologia
- Dermatologia
- Ginecologia
- Ortopedia
- Pediatria
- Psicologia
- Clínica Geral');
  } else {
    response.body(
      'Olá! 👋 Bem-vindo à LN Especialidades.

Digite o número de uma das opções abaixo:
' +
      '1️⃣ Agendar consulta
2️⃣ Atendentes
3️⃣ Endereço
4️⃣ Horário de atendimento
5️⃣ Especialidades'
    );
  }

  res.set('Content-Type', 'text/xml');
  res.send(twiml.toString());
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Bot da LN Especialidades rodando na porta ' + PORT);
});